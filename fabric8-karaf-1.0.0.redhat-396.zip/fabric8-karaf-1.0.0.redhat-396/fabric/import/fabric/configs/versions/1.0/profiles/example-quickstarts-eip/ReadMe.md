# Example QuickStart: Enterprise Integration Patterns

Runs the Camel EIP quickstart example