# Example QuickStart: Secure SOAP

Runs the Secure SOAP quickstart example

Once you have <a href="#/fabric/containers/createContainer?profileIds={{profileId}}">created a container for this profile</a>, or <a href="#/fabric/assignProfile?vid={{versionId}}&amp;pid={{profileId}}">added this profile to a container</a>, you can view the API of the running services in the <a href="#/fabric/api">API tab in the Fabric Runtime view</a>